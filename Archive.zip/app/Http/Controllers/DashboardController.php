<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\App;
use App\Models\Template;
use App\Models\Setting;
use Jenssegers\Agent\Agent;
use Illuminate\Support\Facades\Http;

class DashboardController extends Controller
{
    public function index(Request $request){
        if(!empty($request->apiKey) && !empty($request->wallId)){
            $affiliateRecord = User::where('api_key',$request->apiKey)->where('status',1)->first();
            $appDetails = App::where('appId',base64_decode($request->wallId))->where('status',1)->first();
            $offerWallTemplate = Template::where('app_id',$appDetails->id)->first();
            if(empty($offerWallTemplate)){
                $offerWallTemplate = Template::find(1);
            }
            $offerSettings = Setting::find(1);
            if(!empty($affiliateRecord) && !empty($appDetails)){
                //User Agents
                $agentDetails = new Agent();
                if ($agentDetails->isMobile()) {
                    $deviceType = 'mobile';
                } elseif ($agentDetails->isTablet()) {
                    $deviceType = 'tablet';
                } else {
                    $deviceType = 'desktop';
                }
                
                $userCountry = $this->getUserCountry(request()->ip());
                //End
                $url = env('AFFISE_API_END') . "partner/offers?sort[epc]=desc&limit=50&countries[]=$userCountry";
                $response = HTTP::withHeaders([
                    'API-Key' => $affiliateRecord->affise_api_key,
                ])->get($url);
                if ($response->successful()) {
                    $allOffers = $response->json();
                }else{
                    die('No offer found');
                }
            }else{
                die('Not a valid affiliate');
            }
        }else{
            die('Not a valid request');
        }
        return view('offerwall',compact('allOffers','offerWallTemplate','offerSettings','appDetails','deviceType'));
    }

    public function getUserCountry($ip)
    {
        $url = "http://ipinfo.io/{$ip}/json";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $response = curl_exec($ch);
        curl_close($ch);
        $data = json_decode($response, true);
        
        return $data['country'] ?? 'IN';
    }

}
