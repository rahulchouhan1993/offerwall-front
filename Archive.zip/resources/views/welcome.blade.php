<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="Googlebot-News" content="noindex, nnofollow">
	<meta name="googlebot" content="noindex, nofollow">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Offerwall.XXX</title>
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.3.0/fonts/remixicon.css" rel="stylesheet"/>
    <link rel="stylesheet" href="css/bootstrap.min.css?dfgdg">
    <link rel="stylesheet" href="css/style.css?dfgdg">
    <link rel="icon" type="image/x-icon" href="images/favicon.png">
    
</head>
<body>
<div class="container">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
          <a class="navbar-brand" href="#"><img src="images/logo.png" alt="img" ></a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav m-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link " aria-current="page"  href="#one">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link"  href="#two">Features</a>
              </li>
              <li class="nav-item">
                <a class="nav-link"  href="#three">For Publishers</a>
              </li>
              <li class="nav-item">
                <a class="nav-link"  href="#four">For Advertisers</a>
              </li>
              <li class="nav-item">
                <a class="nav-link"  href="#five">About Us</a>
              </li>

          </div>
          <div class="contact">
            <button class="btn btn-primary">Contact</button>
          </div>
        </div>
    </nav>






     <section id="one"><div class="flex items-center justify-between flex-col-sm gap35 py-30 md-py-40 lg-py-70 ">
        <div class="w-50 w-100-sm">
            <h2 class="hmTitle">Boost Business</h2>
            <h3 class="hmHeading">A Sophisticated Solution for Niche</h3>
            <h4 class="hmName">Monetization</h4>
            <p class="hmPara">Unlock premium engagement and revenue with our innovative offerwall technology. Whether you serve specialized platforms, mature audiences, or unique verticals, we elevate your monetization potential.</p>
            <div class="flex justify-start gap15 pt50">
                <button class="btn btn-primary">Get Started Now</button>
                <button class="btn btn-secondary">Learn More</button>
            </div>
        </div>
        <div class="w-50 w-100-sm text-end">
            <img class="img-fluid round" src="images/sophist.jpg" alt="img">
        </div>
        </div> 
    </section> 

      <section id="two"> <div class="flex items-center justify-between flex-col-sm gap35 py-30 md-py-40 lg-py-70">
        <div class="w-45 w-100-sm">
            <h2 class="hmTitle">Why Choose?</h2>
            <img class="img-fluid round" src="images/whychoos.jpg" alt="img">
        </div>

        <div class="w-55 w-100-sm">
        
            <h3 class="hmHeading text-capitalize">Where <span>innovation</span> <br> meets impact</h3>
            <div class="flex innvosec">
                <div class="innvbx">
                    <svg width="51" height="50" viewBox="0 0 51 50" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M47.6087 25L50.372 20.2242C50.7042 19.6496 50.7945 18.9667 50.6232 18.3255C50.4518 17.6844 50.0329 17.1375 49.4584 16.8051L44.6777 14.0418V8.53518C44.6777 7.87135 44.414 7.2347 43.9446 6.76529C43.4752 6.29589 42.8385 6.03218 42.1747 6.03218H36.6705L33.9097 1.25394C33.5779 0.679074 33.0314 0.259517 32.3904 0.0875364C32.0728 0.00243809 31.7415 -0.0192568 31.4156 0.0236905C31.0896 0.0666378 30.7753 0.173386 30.4906 0.337837L25.7098 3.10116L20.929 0.335334C20.3541 0.00342956 19.671 -0.086515 19.0297 0.085286C18.3885 0.257087 17.8418 0.676562 17.5099 1.25143L14.7466 6.03218H9.24244C8.57859 6.03218 7.94194 6.29589 7.47254 6.76529C7.00313 7.2347 6.73942 7.87135 6.73942 8.53518V14.0393L1.95865 16.8026C1.67388 16.9672 1.42433 17.1863 1.22427 17.4473C1.02422 17.7084 0.877575 18.0063 0.792728 18.3241C0.707881 18.6419 0.686493 18.9732 0.729788 19.2993C0.773083 19.6253 0.880211 19.9396 1.04505 20.2242L3.80838 25L1.04505 29.7757C0.714622 30.3508 0.624972 31.0333 0.795644 31.6742C0.966316 32.3152 1.38347 32.8627 1.95615 33.1973L6.73691 35.9606V41.4647C6.73691 42.1286 7.00062 42.7652 7.47003 43.2346C7.93944 43.704 8.57609 43.9677 9.23993 43.9677H14.7466L17.5099 48.7485C17.7315 49.1273 18.0479 49.4419 18.428 49.6613C18.808 49.8808 19.2387 49.9975 19.6775 50C20.113 50 20.5461 49.8849 20.9315 49.6621L25.7073 46.8988L30.4881 49.6621C31.0627 49.9942 31.7456 50.0845 32.3868 49.9132C33.028 49.7419 33.5748 49.3229 33.9072 48.7485L36.668 43.9677H42.1722C42.836 43.9677 43.4726 43.704 43.9421 43.2346C44.4115 42.7652 44.6752 42.1286 44.6752 41.4647V35.9606L49.4559 33.1973C49.7407 33.0327 49.9903 32.8137 50.1903 32.5526C50.3904 32.2915 50.537 31.9936 50.6219 31.6758C50.7067 31.3581 50.7281 31.0267 50.6848 30.7007C50.6415 30.3746 50.5344 30.0603 50.3695 29.7757L47.6087 25ZM19.4497 12.4599C20.4458 12.4602 21.401 12.8562 22.1051 13.5608C22.8092 14.2654 23.2046 15.2208 23.2043 16.2169C23.2039 17.213 22.8079 18.1682 22.1034 18.8723C21.3988 19.5764 20.4433 19.9718 19.4472 19.9714C18.4512 19.9711 17.496 19.5751 16.7919 18.8705C16.0878 18.1659 15.6924 17.2105 15.6927 16.2144C15.693 15.2183 16.0891 14.2632 16.7936 13.5591C17.4982 12.8549 18.4537 12.4596 19.4497 12.4599ZM20.2007 36.4888L16.1958 33.4877L31.2139 13.4636L35.2188 16.4647L20.2007 36.4888ZM31.9648 37.49C31.4716 37.4898 30.9833 37.3925 30.5277 37.2036C30.0721 37.0147 29.6581 36.7379 29.3095 36.389C28.9608 36.0402 28.6843 35.6261 28.4957 35.1703C28.3071 34.7146 28.2102 34.2262 28.2103 33.733C28.2105 33.2397 28.3078 32.7514 28.4967 32.2958C28.6856 31.8402 28.9624 31.4262 29.3112 31.0776C29.6601 30.729 30.0742 30.4524 30.53 30.2639C30.9857 30.0753 31.4741 29.9783 31.9673 29.9784C32.9634 29.9788 33.9186 30.3748 34.6227 31.0794C35.3268 31.7839 35.7222 32.7394 35.7219 33.7355C35.7215 34.7315 35.3255 35.6867 34.6209 36.3908C33.9164 37.0949 32.9609 37.4903 31.9648 37.49Z" fill="#E888DE"/>
                        </svg>
                        
                    <div class="innvocnt">
                        <h2>Seamless Integration</h2>
                        <p>Effortless setup with SDKs and flexible API options</p>
                    </div>
                </div>

                <div class="innvbx">
                    <svg width="51" height="50" viewBox="0 0 51 50" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M47.6087 25L50.372 20.2242C50.7042 19.6496 50.7945 18.9667 50.6232 18.3255C50.4518 17.6844 50.0329 17.1375 49.4584 16.8051L44.6777 14.0418V8.53518C44.6777 7.87135 44.414 7.2347 43.9446 6.76529C43.4752 6.29589 42.8385 6.03218 42.1747 6.03218H36.6705L33.9097 1.25394C33.5779 0.679074 33.0314 0.259517 32.3904 0.0875364C32.0728 0.00243809 31.7415 -0.0192568 31.4156 0.0236905C31.0896 0.0666378 30.7753 0.173386 30.4906 0.337837L25.7098 3.10116L20.929 0.335334C20.3541 0.00342956 19.671 -0.086515 19.0297 0.085286C18.3885 0.257087 17.8418 0.676562 17.5099 1.25143L14.7466 6.03218H9.24244C8.57859 6.03218 7.94194 6.29589 7.47254 6.76529C7.00313 7.2347 6.73942 7.87135 6.73942 8.53518V14.0393L1.95865 16.8026C1.67388 16.9672 1.42433 17.1863 1.22427 17.4473C1.02422 17.7084 0.877575 18.0063 0.792728 18.3241C0.707881 18.6419 0.686493 18.9732 0.729788 19.2993C0.773083 19.6253 0.880211 19.9396 1.04505 20.2242L3.80838 25L1.04505 29.7757C0.714622 30.3508 0.624972 31.0333 0.795644 31.6742C0.966316 32.3152 1.38347 32.8627 1.95615 33.1973L6.73691 35.9606V41.4647C6.73691 42.1286 7.00062 42.7652 7.47003 43.2346C7.93944 43.704 8.57609 43.9677 9.23993 43.9677H14.7466L17.5099 48.7485C17.7315 49.1273 18.0479 49.4419 18.428 49.6613C18.808 49.8808 19.2387 49.9975 19.6775 50C20.113 50 20.5461 49.8849 20.9315 49.6621L25.7073 46.8988L30.4881 49.6621C31.0627 49.9942 31.7456 50.0845 32.3868 49.9132C33.028 49.7419 33.5748 49.3229 33.9072 48.7485L36.668 43.9677H42.1722C42.836 43.9677 43.4726 43.704 43.9421 43.2346C44.4115 42.7652 44.6752 42.1286 44.6752 41.4647V35.9606L49.4559 33.1973C49.7407 33.0327 49.9903 32.8137 50.1903 32.5526C50.3904 32.2915 50.537 31.9936 50.6219 31.6758C50.7067 31.3581 50.7281 31.0267 50.6848 30.7007C50.6415 30.3746 50.5344 30.0603 50.3695 29.7757L47.6087 25ZM19.4497 12.4599C20.4458 12.4602 21.401 12.8562 22.1051 13.5608C22.8092 14.2654 23.2046 15.2208 23.2043 16.2169C23.2039 17.213 22.8079 18.1682 22.1034 18.8723C21.3988 19.5764 20.4433 19.9718 19.4472 19.9714C18.4512 19.9711 17.496 19.5751 16.7919 18.8705C16.0878 18.1659 15.6924 17.2105 15.6927 16.2144C15.693 15.2183 16.0891 14.2632 16.7936 13.5591C17.4982 12.8549 18.4537 12.4596 19.4497 12.4599ZM20.2007 36.4888L16.1958 33.4877L31.2139 13.4636L35.2188 16.4647L20.2007 36.4888ZM31.9648 37.49C31.4716 37.4898 30.9833 37.3925 30.5277 37.2036C30.0721 37.0147 29.6581 36.7379 29.3095 36.389C28.9608 36.0402 28.6843 35.6261 28.4957 35.1703C28.3071 34.7146 28.2102 34.2262 28.2103 33.733C28.2105 33.2397 28.3078 32.7514 28.4967 32.2958C28.6856 31.8402 28.9624 31.4262 29.3112 31.0776C29.6601 30.729 30.0742 30.4524 30.53 30.2639C30.9857 30.0753 31.4741 29.9783 31.9673 29.9784C32.9634 29.9788 33.9186 30.3748 34.6227 31.0794C35.3268 31.7839 35.7222 32.7394 35.7219 33.7355C35.7215 34.7315 35.3255 35.6867 34.6209 36.3908C33.9164 37.0949 32.9609 37.4903 31.9648 37.49Z" fill="#E888DE"/>
                        </svg>
                        
                    <div class="innvocnt">
                        <h2>Exclusive Offers</h2>
                        <p>Partnering with top-tier brands to deliver curated, high-value offers.</p>
                    </div>
                </div>

                <div class="innvbx">
                    <svg width="51" height="50" viewBox="0 0 51 50" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M47.6087 25L50.372 20.2242C50.7042 19.6496 50.7945 18.9667 50.6232 18.3255C50.4518 17.6844 50.0329 17.1375 49.4584 16.8051L44.6777 14.0418V8.53518C44.6777 7.87135 44.414 7.2347 43.9446 6.76529C43.4752 6.29589 42.8385 6.03218 42.1747 6.03218H36.6705L33.9097 1.25394C33.5779 0.679074 33.0314 0.259517 32.3904 0.0875364C32.0728 0.00243809 31.7415 -0.0192568 31.4156 0.0236905C31.0896 0.0666378 30.7753 0.173386 30.4906 0.337837L25.7098 3.10116L20.929 0.335334C20.3541 0.00342956 19.671 -0.086515 19.0297 0.085286C18.3885 0.257087 17.8418 0.676562 17.5099 1.25143L14.7466 6.03218H9.24244C8.57859 6.03218 7.94194 6.29589 7.47254 6.76529C7.00313 7.2347 6.73942 7.87135 6.73942 8.53518V14.0393L1.95865 16.8026C1.67388 16.9672 1.42433 17.1863 1.22427 17.4473C1.02422 17.7084 0.877575 18.0063 0.792728 18.3241C0.707881 18.6419 0.686493 18.9732 0.729788 19.2993C0.773083 19.6253 0.880211 19.9396 1.04505 20.2242L3.80838 25L1.04505 29.7757C0.714622 30.3508 0.624972 31.0333 0.795644 31.6742C0.966316 32.3152 1.38347 32.8627 1.95615 33.1973L6.73691 35.9606V41.4647C6.73691 42.1286 7.00062 42.7652 7.47003 43.2346C7.93944 43.704 8.57609 43.9677 9.23993 43.9677H14.7466L17.5099 48.7485C17.7315 49.1273 18.0479 49.4419 18.428 49.6613C18.808 49.8808 19.2387 49.9975 19.6775 50C20.113 50 20.5461 49.8849 20.9315 49.6621L25.7073 46.8988L30.4881 49.6621C31.0627 49.9942 31.7456 50.0845 32.3868 49.9132C33.028 49.7419 33.5748 49.3229 33.9072 48.7485L36.668 43.9677H42.1722C42.836 43.9677 43.4726 43.704 43.9421 43.2346C44.4115 42.7652 44.6752 42.1286 44.6752 41.4647V35.9606L49.4559 33.1973C49.7407 33.0327 49.9903 32.8137 50.1903 32.5526C50.3904 32.2915 50.537 31.9936 50.6219 31.6758C50.7067 31.3581 50.7281 31.0267 50.6848 30.7007C50.6415 30.3746 50.5344 30.0603 50.3695 29.7757L47.6087 25ZM19.4497 12.4599C20.4458 12.4602 21.401 12.8562 22.1051 13.5608C22.8092 14.2654 23.2046 15.2208 23.2043 16.2169C23.2039 17.213 22.8079 18.1682 22.1034 18.8723C21.3988 19.5764 20.4433 19.9718 19.4472 19.9714C18.4512 19.9711 17.496 19.5751 16.7919 18.8705C16.0878 18.1659 15.6924 17.2105 15.6927 16.2144C15.693 15.2183 16.0891 14.2632 16.7936 13.5591C17.4982 12.8549 18.4537 12.4596 19.4497 12.4599ZM20.2007 36.4888L16.1958 33.4877L31.2139 13.4636L35.2188 16.4647L20.2007 36.4888ZM31.9648 37.49C31.4716 37.4898 30.9833 37.3925 30.5277 37.2036C30.0721 37.0147 29.6581 36.7379 29.3095 36.389C28.9608 36.0402 28.6843 35.6261 28.4957 35.1703C28.3071 34.7146 28.2102 34.2262 28.2103 33.733C28.2105 33.2397 28.3078 32.7514 28.4967 32.2958C28.6856 31.8402 28.9624 31.4262 29.3112 31.0776C29.6601 30.729 30.0742 30.4524 30.53 30.2639C30.9857 30.0753 31.4741 29.9783 31.9673 29.9784C32.9634 29.9788 33.9186 30.3748 34.6227 31.0794C35.3268 31.7839 35.7222 32.7394 35.7219 33.7355C35.7215 34.7315 35.3255 35.6867 34.6209 36.3908C33.9164 37.0949 32.9609 37.4903 31.9648 37.49Z" fill="#E888DE"/>
                        </svg>
                        
                    <div class="innvocnt">
                        <h2>Adaptable Monetization</h2>
                        <p>Perfect for high-traffic sites, niche markets, and mature audiences.</p>
                    </div>
                </div>

                <div class="innvbx">
                    <svg width="51" height="50" viewBox="0 0 51 50" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M47.6087 25L50.372 20.2242C50.7042 19.6496 50.7945 18.9667 50.6232 18.3255C50.4518 17.6844 50.0329 17.1375 49.4584 16.8051L44.6777 14.0418V8.53518C44.6777 7.87135 44.414 7.2347 43.9446 6.76529C43.4752 6.29589 42.8385 6.03218 42.1747 6.03218H36.6705L33.9097 1.25394C33.5779 0.679074 33.0314 0.259517 32.3904 0.0875364C32.0728 0.00243809 31.7415 -0.0192568 31.4156 0.0236905C31.0896 0.0666378 30.7753 0.173386 30.4906 0.337837L25.7098 3.10116L20.929 0.335334C20.3541 0.00342956 19.671 -0.086515 19.0297 0.085286C18.3885 0.257087 17.8418 0.676562 17.5099 1.25143L14.7466 6.03218H9.24244C8.57859 6.03218 7.94194 6.29589 7.47254 6.76529C7.00313 7.2347 6.73942 7.87135 6.73942 8.53518V14.0393L1.95865 16.8026C1.67388 16.9672 1.42433 17.1863 1.22427 17.4473C1.02422 17.7084 0.877575 18.0063 0.792728 18.3241C0.707881 18.6419 0.686493 18.9732 0.729788 19.2993C0.773083 19.6253 0.880211 19.9396 1.04505 20.2242L3.80838 25L1.04505 29.7757C0.714622 30.3508 0.624972 31.0333 0.795644 31.6742C0.966316 32.3152 1.38347 32.8627 1.95615 33.1973L6.73691 35.9606V41.4647C6.73691 42.1286 7.00062 42.7652 7.47003 43.2346C7.93944 43.704 8.57609 43.9677 9.23993 43.9677H14.7466L17.5099 48.7485C17.7315 49.1273 18.0479 49.4419 18.428 49.6613C18.808 49.8808 19.2387 49.9975 19.6775 50C20.113 50 20.5461 49.8849 20.9315 49.6621L25.7073 46.8988L30.4881 49.6621C31.0627 49.9942 31.7456 50.0845 32.3868 49.9132C33.028 49.7419 33.5748 49.3229 33.9072 48.7485L36.668 43.9677H42.1722C42.836 43.9677 43.4726 43.704 43.9421 43.2346C44.4115 42.7652 44.6752 42.1286 44.6752 41.4647V35.9606L49.4559 33.1973C49.7407 33.0327 49.9903 32.8137 50.1903 32.5526C50.3904 32.2915 50.537 31.9936 50.6219 31.6758C50.7067 31.3581 50.7281 31.0267 50.6848 30.7007C50.6415 30.3746 50.5344 30.0603 50.3695 29.7757L47.6087 25ZM19.4497 12.4599C20.4458 12.4602 21.401 12.8562 22.1051 13.5608C22.8092 14.2654 23.2046 15.2208 23.2043 16.2169C23.2039 17.213 22.8079 18.1682 22.1034 18.8723C21.3988 19.5764 20.4433 19.9718 19.4472 19.9714C18.4512 19.9711 17.496 19.5751 16.7919 18.8705C16.0878 18.1659 15.6924 17.2105 15.6927 16.2144C15.693 15.2183 16.0891 14.2632 16.7936 13.5591C17.4982 12.8549 18.4537 12.4596 19.4497 12.4599ZM20.2007 36.4888L16.1958 33.4877L31.2139 13.4636L35.2188 16.4647L20.2007 36.4888ZM31.9648 37.49C31.4716 37.4898 30.9833 37.3925 30.5277 37.2036C30.0721 37.0147 29.6581 36.7379 29.3095 36.389C28.9608 36.0402 28.6843 35.6261 28.4957 35.1703C28.3071 34.7146 28.2102 34.2262 28.2103 33.733C28.2105 33.2397 28.3078 32.7514 28.4967 32.2958C28.6856 31.8402 28.9624 31.4262 29.3112 31.0776C29.6601 30.729 30.0742 30.4524 30.53 30.2639C30.9857 30.0753 31.4741 29.9783 31.9673 29.9784C32.9634 29.9788 33.9186 30.3748 34.6227 31.0794C35.3268 31.7839 35.7222 32.7394 35.7219 33.7355C35.7215 34.7315 35.3255 35.6867 34.6209 36.3908C33.9164 37.0949 32.9609 37.4903 31.9648 37.49Z" fill="#E888DE"/>
                        </svg>
                        
                    <div class="innvocnt">
                        <h2>Cutting-Edge Technology</h2>
                        <p>Advanced algorithms designed to optimize revenue across diverse platforms.</p>
                    </div>
                </div>
            </div>
            <div class="flex justify-between gap10 pt50">
                <button class="btn btn-primary">Discover All Features</button>
            </div>
        </div>
    
    </div></section> 




     <section id="three"> <div class="flex items-center justify-between flex-col-sm gap35 py-30 md-py-40 lg-py-70">
        <div class="w-50 w-100-sm">
            <h2 class="hmTitle text-capitalize">FOR PUBLISHERS</h2>
            <h3 class="hmHeading text-capitalize mb-3">Monetize <em>with</em> <br> Precision</h3>
            <p class="hmPara mb-5">Whether you operate in entertainment, lifestyle, or specialized content, our offerwall adapts to your audience. Ideal for platforms catering to mature or niche interests, we provide a respectful, high-yield solution.</p>
            <div class="flex justify-between gap10">
                <button class="btn btn-primary">Partner With Us</button>
            </div>
        </div>
        <div class="w-50 w-100-sm text-center">
            <img class="img-fluid round" src="images/publisherimg.png" alt="img">
        </div>
    </div> </section> 
   


<section id="four">
    <div class="flex items-center justify-between flex-col-sm gap35 py-30 md-py-40 lg-py-70">
        <div class="w-50 w-100-sm">
            <img class="img-fluid round" src="images/reachimg.png" alt="img">
        </div>

        <div class="w-50 w-100-sm">
            <h2 class="hmTitle">FOR ADVERTISERS</h2>
            <h3 class="hmHeading text-capitalize mb-4">Reach <span>Discerning</span> Audiences</h3>
            <p class="hmPara mb-5">Promote your brand to an engaged and diverse audience across premium platforms. From lifestyle and wellness products to intimate essentials, our network ensures your offers land in front of the right eyes.</p>
            <div class="flex justify-between gap10">
                <button class="btn btn-primary">Advertise With Us</button>
            </div>
        </div>
        
    </div> </section> 

     
    <section id="five"> <div class="whowe">
        <h2 class="hmTitle text-center">Who we are?</h2>
        <h3 class="hmHeading text-center  text-capitalize mb-5">Our team <span>consists</span> of monetizing experts passionate about helping businesses succeed online</h3>

        <div class="flex justify-between items-center flex-col-sm gap10">
            <div class="w-50 w-100-sm text-center">
                <img class="img-fluid round" src="images/whowe.png" alt="img">
            </div>
        
            <div class="w-50 w-100-sm">
            <p class="hmPara">At OfferWall, we specialize in monetizing unique markets and diverse platforms. From conventional to niche industries, we create meaningful connections between advertisers and audiences.</p>
            
            </div>
        </div> 

        <div class="flex justify-center gap10 pt50 ">
            <button class="btn btn-primary">Read More About Our Vision</button>
        </div>
    </div> 
</div> </section>


<!-- Footer -->
 <footer>
    <div class="footnav">
        <div class="container">
        <div class="row">
            <div class="col-md-3 col-lg-6 footlogo">
                <img src="images/footlogo.png" alt="img"> 
            </div>
            <div class="col-md-9 col-lg-6 flex flex-col-sm">
                <div class="footlink">
                    <h2>Company</h2>
                    <ul>
                        <li><a href="#">About us</a></li>
                        <li><a href="#">Careers</a></li>
                        <li><a href="#">Contact</a></li>
                    </ul>
                </div>

                <div class="footlink">
                    <h2>Resources</h2>
                    <ul>
                        <li><a href="#">Blog</a></li>
                        <li><a href="#">Help center</a></li>
                        <li><a href="#">Support</a></li>
                    </ul>
                </div>

                <div class="footlink">
                    <h2>Social</h2>
                    <ul>
                        <li><a href="#">Twitter</a></li>
                        <li><a href="#">LinkedIn</a></li>
                        <li><a href="#">Facebook</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    </div>
    <div class="copyright">© 2025 <span>Offerwall.xxx.</span> All rights reserved.</div>
 </footer>  






 <!--Java Script  -->
 <script src="js/jquery-3.7.1.js"></script> 
 <script src="js/bootstrap.bundle.min.js"></script> 
 
 <script>
    function menuOnScroll(mySection, myMenu, myClass) {
  $(window).scroll(function () {
    var elScroll = $(window).scrollTop();
    var currentSection = null;

    $(mySection).each(function () {
      if ($(this).offset().top <= elScroll + $('nav').outerHeight()) {
        currentSection = this;
      }
    });

    if (currentSection) {
      var id = $(currentSection).attr('id');
      $(myMenu).removeClass(myClass);
      $('nav ul li a[href="#' + id + '"]').addClass(myClass);
    }
  });
}

function scrollToAnyPoint(navItem) {
  $(navItem).click(function (e) {
    e.preventDefault();
    var target = $(this).attr('href');
    var toSection = $(target).offset().top - $('nav').outerHeight();

    $("html, body").animate({ scrollTop: toSection }, 700, function () {
      $(window).trigger("scroll");
    });
  });
}

// jQuery Load Check
$(document).ready(function () {
  menuOnScroll('section', 'nav ul li a', 'inSection');
  scrollToAnyPoint('nav ul li a');
});

    </script>

</body>
</html>